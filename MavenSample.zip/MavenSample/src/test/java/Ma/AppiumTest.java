package Ma;

import org.testng.annotations.Test;

//import org.testng.annotations.Test;

public class AppiumTest {
	
	@Test
	public void NativeAndroid()
	{
		System.out.println("NativeAndroid");
	}
	
	@Test
	public void NativeiOS()
	{
		System.out.println("NativeiOS");
	}

}
