package Ma;

import org.testng.annotations.Test;

public class SeleniumTest {
	
	
	
	@Test
	public void BrowserTest()
	{
		System.out.println("BrowserTest");

	}
	
	@Test
	public void SecondBrowserTest()
	{
		System.out.println("SecondBrowserTest");

	}

}
