package Ma;

import org.testng.annotations.Test;

public class RestAPITest {
	
	@Test
	public void PostJIRA()
	{
		System.out.println("PostJIRA");
	}
	
	@Test
	public void DeleteTwitter()
	{
		System.out.println("DeleteTwitter");
	}

}
